package com.sjsu.se195.uniride;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.fyp.baigktk.cuifr.MainSubcategoryActivity;
import com.fyp.baigktk.cuifr.NewPostActivity;
import com.fyp.baigktk.cuifr.R;
import com.fyp.baigktk.cuifr.models.Post;
import com.fyp.baigktk.cuifr.models.PostInfoModel;
import com.fyp.baigktk.cuifr.models.RoutePoints;
import com.fyp.baigktk.cuifr.models.User;
import com.fyp.baigktk.cuifr.models.UserModel;
import com.fyp.baigktk.cuifr.models.driveOfferModel;
import com.google.android.gms.maps.model.LatLng;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.messaging.FirebaseMessaging;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

public class DriverInfoActivity extends AppCompatActivity {

    UserModel mUser=new UserModel();


    private String riderKey=FirebaseAuth.getInstance().getCurrentUser().getUid();
    private FirebaseDatabase mDatabase = FirebaseDatabase.getInstance();
    private DatabaseReference mDatabaseReference = mDatabase.getReference();
    private TextView mName,mTotalPassengers,mSource,mDestination,mDate,mDepartureTime,mArrivaleTime, mAC,mMusic,mSmoking,mGender,mFareAmount;
    private Button mSubmitButton;
    LatLng pickupPoint;
    PostInfoModel pm=new PostInfoModel();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_driver_info);
        Bundle b=getIntent().getParcelableExtra("bundle");
        LatLng nearbyRP=b.getParcelable("nearbyRP");
        pickupPoint=b.getParcelable("pickupPoint");
        initializations();
        setInfoToViews();



        mSubmitButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                SendRequestToDriver();
            }
        });



    }

    private void setInfoToViews() {

        mName.setText("Name: "+pm.getAuthor());
        mTotalPassengers.setText("Max Passengers: "+pm.getPassengerCount());
        mSource.setText("Source: "+pm.getSource());
        mDestination.setText("Destination: "+pm.getDestination());
        mDate.setText("Date: "+pm.getTripDate());
        mDepartureTime.setText("Departure Time: "+pm.getDepartureTime());
        mArrivaleTime.setText("Arrival Time: "+pm.getArrivalTime());

        if (pm.getDriverPreferences().isAc()) { mAC.setText("AC: Yes"); }
        else{ mAC.setText("AC: No"); }

        if (pm.getDriverPreferences().isSmoking()) {  mSmoking.setText("Smoking: Yes");   }
        else {  mSmoking.setText("Smoking: No"); }

        if(pm.getDriverPreferences().isMusic()) {   mMusic.setText("Music: Yes");}
        else {  mMusic.setText("Music: No");}

        if (pm.getDriverPreferences().getGender().equals("Male"))
        {
            mGender.setText("Gender: Male only");
        }
        else if (pm.getDriverPreferences().getGender().equals("Female"))
        {
            mGender.setText("Gender: Female only");
        }
        else if (pm.getDriverPreferences().getGender().equals("Both"))
        {
            mGender.setText("Gender: Any");
        }

    }

    private void initializations() {


        Intent i=getIntent();
        pm=(PostInfoModel) i.getSerializableExtra("driverInfo");

        getRiderInfo();
        mName=findViewById(R.id.driver_info_name);
        mTotalPassengers=findViewById(R.id.driver_info_totalPassengers);
        mSource=findViewById(R.id.driver_info_Source);
        mDestination=findViewById(R.id.driver_info_destination);
        mDate=findViewById(R.id.driver_info_Date);
        mDepartureTime=findViewById(R.id.driver_info_departureTime);
        mArrivaleTime=findViewById(R.id.driver_info_arrivalTime);

        mAC=findViewById(R.id.driver_info_preferences_AC);
        mSmoking=findViewById(R.id.driver_info_preferences_Smoking);
        mMusic=findViewById(R.id.driver_info_preferences_Music);
        mGender=findViewById(R.id.driver_info_preferences_Gender);

        mFareAmount=findViewById(R.id.driver_info_fare_amount);
        mSubmitButton=findViewById(R.id.driver_info_fare_submit_btn);


    }

    private void getRiderInfo()
    {
        DatabaseReference usersRef=mDatabaseReference.child("users").child(riderKey);

        usersRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                mUser=dataSnapshot.getValue(UserModel.class);
                assert mUser != null;
                mUser.setPickupPoint(pickupPoint);
                mUser.setFareAmount(150);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Toast.makeText(DriverInfoActivity.this, databaseError.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    public void SendRequestToDriver() {
        String myKey=FirebaseAuth.getInstance().getCurrentUser().getUid();
        DatabaseReference riderRequestRef=mDatabaseReference.child("rideRequest").child(pm.getUserKey()).child(myKey);
        riderRequestRef.setValue(mUser);
        Toast.makeText(this, "Request Sent to Driver", Toast.LENGTH_SHORT).show();
        finish();
    }

//
//    public void SendNotification(View view) {
//        // Create a list containing up to 100 registration tokens.
//// These registration tokens come from the client FCM SDKs.
//        List<String> registrationTokens = Arrays.asList(
//                "YOUR_REGISTRATION_TOKEN_1",
//                // ...
//                "YOUR_REGISTRATION_TOKEN_n"
//        );
//
//        MulticastMessage message = MulticastMessage.builder()
//                .putData("score", "850")
//                .putData("time", "2:45")
//                .addAllTokens(registrationTokens)
//                .build();
//        BatchResponse response = FirebaseMessaging.getInstance().sendMulticast(message);
//// See the BatchResponse reference documentation
//// for the contents of response.
//        System.out.println(response.getSuccessCount() + " messages were sent successfully");FirebaseMessagingSnippets.java
//    }
    
    
    
    
    //yr is func ko ignore maar
    void hello(){
        PostInfoModel pm2=new PostInfoModel();
        DatabaseReference database = FirebaseDatabase.getInstance().getReference();
        DatabaseReference ref = database.child("match");
        final Query driverPostRef=ref.child(String.valueOf(0));
        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
        final String userEmail = user.getEmail();
        driverPostRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                //String riderDestination_tripDate=rideRequestModel.getDestination()+"_"+rideRequestModel.getDate();

                for (DataSnapshot ds : dataSnapshot.getChildren()) {
                    String Email_address = (String) ds.child("match").child("0").child("email").getValue();
                    if(Email_address.equals(userEmail)) {
                        PostInfoModel postInfoModel2 = new PostInfoModel();
                        postInfoModel2 = ds.child("match").child("0").getValue(PostInfoModel.class);

                        List<PostInfoModel> routePointsList = new ArrayList<>();
                        PostInfoModel routePoints = new PostInfoModel();

                    }
                }

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

    }
}
