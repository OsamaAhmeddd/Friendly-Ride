package com.fyp.baigktk.cuifr.fragment;

import android.app.Fragment;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.fyp.baigktk.cuifr.R;
import com.fyp.baigktk.cuifr.models.UserModel;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;

import afu.org.checkerframework.checker.nullness.qual.Nullable;


public class RiderRequestsFragment extends Fragment {

    RecyclerView recyclerView;
    private FirebaseRecyclerAdapter<UserModel, UserViewHolder> mAdapter;



    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_rider_requests,container,false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        initializations();
        loadDataFromFirebase();

    }

    private void loadDataFromFirebase() {
        String DriverKey= FirebaseAuth.getInstance().getCurrentUser().getUid();
        Query query= FirebaseDatabase.getInstance().getReference().child("rideRequest").child(DriverKey);
        FirebaseRecyclerOptions<UserModel> options =
                new FirebaseRecyclerOptions.Builder<UserModel>()
                        .setQuery(query, UserModel.class)
                        .build();

    }


    private void initializations() {
        recyclerView=getView().findViewById(R.id.fragment_rider_requests_recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
    }
    public static class UserViewHolder extends RecyclerView.ViewHolder {

        View mView;

        public UserViewHolder(@NonNull View itemView) {
            super(itemView);
            mView = itemView;
        }

        public void setDetails(String rider_name, String rider_email,String rider_Fare) {
            TextView name = mView.findViewById(R.id.item_rider_request_name);
            TextView email = mView.findViewById(R.id.item_rider_request_email);
            TextView Fare = mView.findViewById(R.id.item_rider_request_Fare);


            name.setText(rider_name);
            email.setText(rider_email);
            Fare.setText(rider_Fare);




        }

    }
}
