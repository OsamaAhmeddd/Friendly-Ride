package com.fyp.baigktk.cuifr.viewholder;

import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.fyp.baigktk.cuifr.R;
import com.fyp.baigktk.cuifr.models.Post;
import com.fyp.baigktk.cuifr.models.PostInfoModel;

import java.util.List;



public class PostListRecyclerAdapter extends RecyclerView.Adapter<PostListRecyclerAdapter.SearchPostViewHolder> {

    private List<PostInfoModel> mDataset;
    private OnClickListenerr mOnClickListenerr;

    // Provide a suitable constructor (depends on the kind of dataset)
    public PostListRecyclerAdapter(List<PostInfoModel> myDataset,OnClickListenerr mOnClickListenerr) {
        mDataset = myDataset;
        this.mOnClickListenerr=mOnClickListenerr;
    }

    @Override
    public SearchPostViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_matched_post, parent, false);

        return new SearchPostViewHolder(itemView,mOnClickListenerr);
    }

    @Override
    public void onBindViewHolder(SearchPostViewHolder holder, int position) {
        holder.bindToPost(mDataset.get(position));
    }

    // Return the size of your dataset (invoked by the layout manager)
    @Override
    public int getItemCount() {
        return mDataset.size();
    }




    // View Holder inner class:


    public  class SearchPostViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {

        private TextView sourceView;
        private TextView authorView;
        private TextView destinationView;
        private TextView passengerCountTextView;
        private TextView estimatedTravelTimeTextView;
        private TextView estimatedTravelDistanceTextView;
        OnClickListenerr onClickListenerr;

        public SearchPostViewHolder(View itemView,OnClickListenerr onClickListenerr) {
            super(itemView);

            sourceView = (TextView) itemView.findViewById(R.id.post_source);
            authorView = (TextView) itemView.findViewById(R.id.post_cardview_author_name);
            destinationView = (TextView) itemView.findViewById(R.id.post_destination);
            this.onClickListenerr=onClickListenerr;
            passengerCountTextView = itemView.findViewById(R.id.post_passenger_count);
            estimatedTravelTimeTextView = itemView.findViewById(R.id.carpool_estimated_trip_time);
            estimatedTravelDistanceTextView = itemView.findViewById(R.id.carpool_estimated_trip_distance);

            itemView.setOnClickListener(this);
        }

        public void bindToPost(PostInfoModel post) {
            sourceView.setText("From: \n"+post.getSource());
            authorView.setText(post.getAuthor());
            destinationView.setText("To: \n"+post.getDestination());

            passengerCountTextView.setText("Total Passengers: "+post.getPassengerCount());
          //  estimatedTravelTimeTextView.setText();
           // estimatedTravelDistanceTextView.setText("Z23 miles");
        }


        @Override
        public void onClick(View v) {
            onClickListenerr.onItemClick(getAdapterPosition());
        }
    }

    public interface OnClickListenerr {
        void onItemClick(int position);
    }
}
