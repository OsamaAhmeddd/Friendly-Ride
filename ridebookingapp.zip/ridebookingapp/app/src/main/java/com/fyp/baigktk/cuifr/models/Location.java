package com.fyp.baigktk.cuifr.models;



//LATITUDE, LONGITUDE FROM MAPS API and HELPER FUNCTIONS

public class Location {
}
