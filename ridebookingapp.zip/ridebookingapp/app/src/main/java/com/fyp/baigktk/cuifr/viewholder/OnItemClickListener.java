package com.fyp.baigktk.cuifr.viewholder;

import android.view.View;



public interface OnItemClickListener {
    void onClick(View view, int position);
}
